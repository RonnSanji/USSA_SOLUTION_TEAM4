package sg.edu.nus.iss.ssa.exception;

/**
 * 
 * @author Amarjeet B SIngh
 *
 */
public class FieldMismatchExcepion extends Exception {
	
	public FieldMismatchExcepion(String message) {
		super(message);
	}

}
