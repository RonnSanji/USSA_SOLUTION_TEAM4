package sg.edu.nus.iss.ssa.exception;

/**
 * <p/>
 * Created with IntelliJ IDEA. <br/>
 * User: Ankur Jain<br/>
 * Date: 4/9/16 <br/>
 * Time: 5:59 PM <br/>
 */
public class BarCodeException extends Exception {
  public BarCodeException(String message) {
    super(message);
  }
}
